-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 24-02-2020 a las 16:27:12
-- Versión del servidor: 5.7.17
-- Versión de PHP: 7.1.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `videoclubvm`
--
CREATE DATABASE IF NOT EXISTS `videoclubvm` DEFAULT CHARACTER SET utf8 COLLATE utf8_spanish_ci;
USE `videoclubvm`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `juegos`
--

CREATE TABLE `juegos` (
  `Id_Juego` int(20) NOT NULL,
  `Nombre` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `Creador` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `Tipo` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `Precio` int(20) NOT NULL,
  `Stock` int(20) NOT NULL,
  `Descuento` int(20) NOT NULL,
  `Imagen` varchar(255) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `juegos`
--

INSERT INTO `juegos` (`Id_Juego`, `Nombre`, `Creador`, `Tipo`, `Precio`, `Stock`, `Descuento`, `Imagen`) VALUES
(1, 'Metal Gear Solid', 'Konami', 'Fisico', 20, 6, 10, './img/metalGear.jpg'),
(2, 'Rome Total War', 'Sega', 'Digital', 25, 45, 5, './img/TotalWar.jpg'),
(3, 'Sonic', 'Sega', 'Fisico', 20, 9, 3, './img/Sonic.jpg'),
(4, 'GTA-V', 'RockStar', 'Digital', 50, 35, 15, './img/GTA.jpg'),
(5, 'Golden Axe', 'Sega', 'Fisico', 20, 13, 6, './img/GoldenAxe.jpg'),
(6, 'Red Dead Redemption', 'RockStar', 'Fisico', 56, 25, 5, './img/RedDead.jpg'),
(7, 'Max Payne', 'RockStar', 'Digital', 35, 30, 10, './img/MaxPayne.jpg'),
(8, 'Silent Hill', 'Konami', 'Fisico', 34, 8, 1, './img/SilentHill.jpg'),
(9, 'Contra', 'Konami', 'Digital', 12, 12, 2, './img/Contra.jpg'),
(10, 'Castelvania', 'Konami', 'Digital', 17, 9, 4, './img/Castelvania.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `peliculas`
--

CREATE TABLE `peliculas` (
  `Id_Pelicula` int(11) NOT NULL,
  `Nombre` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `Director` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `Sinopsis` varchar(1000) COLLATE utf8_spanish_ci NOT NULL,
  `Imagen` varchar(500) COLLATE utf8_spanish_ci NOT NULL,
  `Stock` int(11) NOT NULL,
  `Ano` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `Genero` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `Precio` int(11) NOT NULL,
  `Descuento` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `peliculas`
--

INSERT INTO `peliculas` (`Id_Pelicula`, `Nombre`, `Director`, `Sinopsis`, `Imagen`, `Stock`, `Ano`, `Genero`, `Precio`, `Descuento`) VALUES
(1, 'El Señor de los Anillos', 'Petter Jackson', 'Un anillo para gobernarlos a todos, un anillo para atraerlos a todos,etc etc..', './img/ElSeñorDeLosAnillos.jpg', 5, '1998', 'Ciencia Ficcion', 10, 25),
(2, 'Torrente', 'Santiago Segura', 'El brazo tonto de la ley..', './img/torrente.jpg', 5, '2000', 'Comedia', 5, 50),
(3, 'El Club de la Lucha', 'David Fincher', 'Un club de lucha clandestino', './img/ClubLucha.jpg', 11, '1999', 'Ciencia Ficcion', 35, 10),
(4, 'El Exorcista', 'William Friedkin', 'Una joven con el demonio dentro y un cura que intenta sacarlo.', './img/Exorcista.jpg', 8, '1997', 'Terror', 40, 5),
(5, 'Hacia Rutas Salvajes', 'Sean Penn', 'Después de su graduación de la universidad, Christopher McCandless regala sus ahorros, se deshace de sus pertenencias y realiza un viaje a través de la vida silvestre de Alaska.', './img/RutasSalvajes.jpg', 22, '2005', 'Ciencia Ficcion', 20, 3),
(6, 'It', 'Andrés Muschietti', 'En el misterioso pueblo de Derry, un malvado payaso llamado Pennywise vuelve 27 años después para atormentar a los ya adultos miembros del Club de los Perdedores, que ahora están más alejados unos de otros.', './img/it.jpg', 12, '2019', 'Terror', 45, 13),
(7, 'Matrix', 'Lana y Lilly Wachowski', 'Un experto en computadoras descubre que su mundo es una simulación total creada con maliciosas intenciones por parte de la ciberinteligencia', './img/matrix.jpg', 17, '1999', 'Ciencia Ficcion', 19, 3),
(8, 'Pulp Fictions', ' Quentin Tarantino', 'La vida de un boxeador, dos sicarios, la esposa de un gánster y dos bandidos se entrelaza en una historia de violencia y redención', './img/pulpFiction.jpg', 15, '1994', 'Accion', 15, 6),
(9, 'Resacon en las Vegas', 'Todd Phillips', 'Dos días antes de su boda, Doug y tres amigos viajan a Las Vegas para una fiesta inolvidable y salvaje.', './img/resacon.jpg', 7, '2009', 'Comedia', 10, 5),
(10, 'ScarFace El precio del poder', 'Brian De Palma', 'Un inmigrante cubano de las cárceles de Fidel Castro provoca un camino de destrucción en su ascenso en el mundo de las drogas de Miami.', './img/scarFace.jpg', 15, '1983', 'Accion', 16, 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reservas`
--

CREATE TABLE `reservas` (
  `Id_Usuario` int(11) NOT NULL,
  `Id_Pelicula` int(11) NOT NULL,
  `Nombre` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `imagen` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `fecha` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `estado` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `precio` int(11) NOT NULL,
  `descuento` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `reservas`
--

INSERT INTO `reservas` (`Id_Usuario`, `Id_Pelicula`, `Nombre`, `imagen`, `fecha`, `estado`, `precio`, `descuento`) VALUES
(4444, 2, 'Torrente', './img/torrente.jpg', '21-02-2020 20:16:44', 'Enviado', 5, 50),
(4444, 2, 'Torrente', './img/torrente.jpg', '21-02-2020 20:29:50', 'Enviado', 5, 50),
(4444, 2, 'Rome Total War', './img/TotalWar.jpg', '21-02-2020 22:51:50', 'Enviado', 5, 50),
(4444, 2, 'Rome Total War', './img/TotalWar.jpg', '21-02-2020 22:52:33', 'Enviado', 5, 50),
(4444, 2, 'Rome Total War', './img/TotalWar.jpg', '21-02-2020 23:29:23', 'Enviado', 5, 50),
(4444, 1, 'Metal Gear Solid', './img/metalGear.jpg', '21-02-2020 23:29:24', 'Enviado', 10, 25),
(4444, 1, 'El Señor de los Anillos', './img/ElSeñorDeLosAnillos.jpg', '21-02-2020 23:30:09', 'Enviado', 10, 25),
(4444, 2, 'Torrente', './img/torrente.jpg', '21-02-2020 23:30:12', 'Enviado', 5, 50),
(4444, 2, 'Rome Total War', './img/TotalWar.jpg', '21-02-2020 23:30:16', 'Enviado', 5, 50),
(4444, 1, 'Metal Gear Solid', './img/metalGear.jpg', '21-02-2020 23:30:17', 'Enviado', 10, 25),
(22, 2, 'Rome Total War', './img/TotalWar.jpg', '22-02-2020 10:46:11', 'Enviado', 5, 50),
(22, 1, 'Metal Gear Solid', './img/metalGear.jpg', '22-02-2020 10:46:14', 'Pagado', 10, 25),
(22, 2, 'Torrente', './img/torrente.jpg', '22-02-2020 10:46:22', 'Enviado', 5, 50),
(4444, 8, 'Silent Hill', './img/SilentHill.jpg', '22-02-2020 12:34:40', 'Enviado', 15, 6),
(4444, 8, 'Silent Hill', './img/SilentHill.jpg', '22-02-2020 12:45:18', 'Enviado', 15, 6),
(4444, 5, 'Golden Axe', './img/GoldenAxe.jpg', '22-02-2020 17:37:35', 'Enviado', 20, 3),
(4444, 5, 'Hacia Rutas Salvajes', './img/RutasSalvajes.jpg', '22-02-2020 18:16:39', 'Enviado', 20, 3),
(4444, 7, 'Matrix', './img/matrix.jpg', '22-02-2020 18:16:41', 'Pagado', 19, 3),
(4444, 9, 'Contra', './img/Contra.jpg', '22-02-2020 18:16:46', 'Pagado', 10, 5),
(4444, 2, 'Rome Total War', './img/TotalWar.jpg', '22-02-2020 18:16:48', 'Pagado', 5, 50),
(4444, 5, 'Hacia Rutas Salvajes', './img/RutasSalvajes.jpg', '22-02-2020 18:42:22', 'Pagado', 20, 3),
(4444, 9, 'Contra', './img/Contra.jpg', '24-02-2020 10:58:58', 'Pagado', 10, 5),
(4444, 5, 'Hacia Rutas Salvajes', './img/RutasSalvajes.jpg', '24-02-2020 11:43:56', 'Pagado', 20, 3),
(4444, 5, 'Hacia Rutas Salvajes', './img/RutasSalvajes.jpg', '24-02-2020 11:45:04', 'Pagado', 20, 3),
(4444, 7, 'Matrix', './img/matrix.jpg', '24-02-2020 11:48:36', 'Pagado', 19, 3),
(48517773, 2, 'Torrente', './img/torrente.jpg', '24-02-2020 16:21:52', 'Enviado', 5, 50),
(48517773, 10, 'Castelvania', './img/Castelvania.jpg', '24-02-2020 16:22:06', 'Pagado', 16, 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `direccion` varchar(500) COLLATE utf8_spanish_ci NOT NULL,
  `clave` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `Correo` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `telefono` varchar(255) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `direccion`, `clave`, `Correo`, `telefono`) VALUES
(22, 'vero', 'C/capitan portola', 'vero', 'vero@gmail.com', '666665555'),
(1234, 'julian', 'C/Mayor Alguazas', 'julian', 'julian@gmail.com', '123456789'),
(4444, 'alvaro', 'C/General Garcia Diaz N 2 CP. 30840 Mayorca', 'alvaro', 'alvaro@correo.es', '66666'),
(78946, 'juli', 'C/MAyor', 'juli', 'juli@gmail.com', '4567893'),
(456789, 'sergio', 'C/Maryor', 'sergio', 'sergio@.cim', '7894565'),
(789456, 'fulanito', 'C/Numancia Nº3 CP.30840 Alhama de Murcia', 'fulanito', 'fulanito@gmail.com', '616457821'),
(1234567, 'fernando', 'C/mandarinas', 'fernando', 'fer@gmail.com', '456577777'),
(48516678, 'Fran', 'C/Roberto martinez', 'Fran', 'Correo@gmail.com', '789456123'),
(48517773, 'Pedro', 'C/Principal N2 40875 Jaen', 'Pedro', 'pedro@correo.com', '654987321'),
(48751234, 'Maria', 'C/Postigos', 'Maria', 'Maria@correo.com', '78945621');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `juegos`
--
ALTER TABLE `juegos`
  ADD PRIMARY KEY (`Id_Juego`);

--
-- Indices de la tabla `peliculas`
--
ALTER TABLE `peliculas`
  ADD PRIMARY KEY (`Id_Pelicula`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `juegos`
--
ALTER TABLE `juegos`
  MODIFY `Id_Juego` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT de la tabla `peliculas`
--
ALTER TABLE `peliculas`
  MODIFY `Id_Pelicula` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
